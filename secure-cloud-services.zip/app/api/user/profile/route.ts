import { NextRequest, NextResponse } from "next/server";
import { verifyToken } from "@/lib/auth";
import { dynamoClient } from "@/lib/aws";
import { GetItemCommand } from "@aws-sdk/client-dynamodb";

export async function GET(req: NextRequest) {
  try {
    const token = req.headers.get("authorization")?.split(" ")[1];
    if (!token) return NextResponse.json({ error: "Missing token" }, { status: 401 });

    const user = await verifyToken(token);
    const command = new GetItemCommand({
      TableName: process.env.DYNAMO_TABLE!,
      Key: { userId: { S: user.sub } },
    });
    const result = await dynamoClient.send(command);

    if (!result.Item)
      return NextResponse.json({ error: "User not found" }, { status: 404 });

    return NextResponse.json(
      {
        id: result.Item.userId.S,
        name: result.Item.name?.S,
        email: result.Item.email?.S,
      },
      { status: 200 }
    );
  } catch (err) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }
}
