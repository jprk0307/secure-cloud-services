# SkillSprout Backend Developer Assignment

## 🚀 Overview
A Next.js (TypeScript) backend implementing 3 secure APIs for AWS Cognito, S3, DynamoDB, and Lambda integration.

## 🧱 Endpoints
1. **GET /api/user/profile** — Securely fetch user profile from DynamoDB.
2. **POST /api/files/prepare-upload** — Generate a pre-signed S3 URL for file uploads.
3. **POST /api/submission/process** — Asynchronously trigger a background Lambda task.

## ⚙️ Setup

### 1️⃣ Install dependencies
```bash
npm install
```

### 2️⃣ Configure Environment
Add `.env.local`:
```
AWS_REGION=ap-south-1
COGNITO_USER_POOL_ID=ap-south-1_XXXXXX
DYNAMO_TABLE=UserProfiles
S3_BUCKET=your-s3-bucket
LAMBDA_FUNCTION=process-submission
```

### 3️⃣ Run the Dev Server
```bash
npm run dev
```

### 4️⃣ Test the APIs (cURL examples)

**Profile API**
```bash
curl -X GET http://localhost:3000/api/user/profile \-H "Authorization: Bearer <JWT_TOKEN>"
```

**Prepare Upload**
```bash
curl -X POST http://localhost:3000/api/files/prepare-upload \-H "Authorization: Bearer <JWT_TOKEN>" \-H "Content-Type: application/json" \-d '{"fileName": "sample.png", "fileType": "image/png"}'
```

**Async Process**
```bash
curl -X POST http://localhost:3000/api/submission/process \-H "Authorization: Bearer <JWT_TOKEN>" \-H "Content-Type: application/json" \-d '{"projectId": "123"}'
```

## 🧹 ESLint
Run code quality check:
```bash
npm run lint
```

## ✅ Notes
- Uses AWS SDK v3 modular clients
- All routes written in TypeScript
- JWT validation handled via Cognito JWKs
