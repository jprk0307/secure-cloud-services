import { NextRequest, NextResponse } from "next/server";
import { verifyToken } from "@/lib/auth";
import { S3Client, PutObjectCommand } from "@aws-sdk/client-s3";
import { getSignedUrl } from "@aws-sdk/s3-request-presigner";
import { randomUUID } from "crypto";

const s3Client = new S3Client({ region: process.env.AWS_REGION });

export async function POST(req: NextRequest) {
  try {
    const token = req.headers.get("authorization")?.split(" ")[1];
    if (!token) return NextResponse.json({ error: "Missing token" }, { status: 401 });

    const user = await verifyToken(token);
    const body = await req.json();
    const { fileName, fileType } = body;

    const fileKey = `uploads/${user.sub}/${randomUUID()}_${fileName}`;

    const command = new PutObjectCommand({
      Bucket: process.env.S3_BUCKET!,
      Key: fileKey,
      ContentType: fileType,
    });

    const signedUrl = await getSignedUrl(s3Client, command, { expiresIn: 600 });

    return NextResponse.json({
      uploadUrl: signedUrl,
      fileKey,
      expiresIn: 600,
    });
  } catch (err) {
    return NextResponse.json({ error: "Upload preparation failed" }, { status: 500 });
  }
}
