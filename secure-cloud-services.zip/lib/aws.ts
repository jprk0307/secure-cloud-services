import { DynamoDBClient } from "@aws-sdk/client-dynamodb";
import { S3Client } from "@aws-sdk/client-s3";
import { LambdaClient } from "@aws-sdk/client-lambda";

export const dynamoClient = new DynamoDBClient({ region: process.env.AWS_REGION });
export const s3Client = new S3Client({ region: process.env.AWS_REGION });
export const lambdaClient = new LambdaClient({ region: process.env.AWS_REGION });
