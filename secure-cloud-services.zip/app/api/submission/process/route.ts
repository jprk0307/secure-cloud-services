import { NextRequest, NextResponse } from "next/server";
import { verifyToken } from "@/lib/auth";
import { lambdaClient } from "@/lib/aws";
import { InvokeCommand } from "@aws-sdk/client-lambda";

export async function POST(req: NextRequest) {
  try {
    const token = req.headers.get("authorization")?.split(" ")[1];
    if (!token) return NextResponse.json({ error: "Missing token" }, { status: 401 });

    const user = await verifyToken(token);
    const payload = await req.json();

    const command = new InvokeCommand({
      FunctionName: process.env.LAMBDA_FUNCTION!,
      InvocationType: "Event",
      Payload: JSON.stringify({ userId: user.sub, ...payload }),
    });

    await lambdaClient.send(command);
    console.log("Async job initiated for user:", user.sub);

    return NextResponse.json({ status: "Job queued" }, { status: 202 });
  } catch (err) {
    return NextResponse.json({ error: "Failed to start process" }, { status: 500 });
  }
}
