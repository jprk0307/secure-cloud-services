import jwt from "jsonwebtoken";
import { JwksClient } from "jwks-rsa";

const region = process.env.AWS_REGION!;
const userPoolId = process.env.COGNITO_USER_POOL_ID!;
const jwksUri = `https://cognito-idp.${region}.amazonaws.com/${userPoolId}/.well-known/jwks.json`;

const client = new JwksClient({ jwksUri });

export async function verifyToken(token: string) {
  try {
    const decodedHeader = jwt.decode(token, { complete: true });
    if (!decodedHeader || typeof decodedHeader === "string") throw new Error("Invalid token header");

    const kid = decodedHeader.header.kid;
    const key = await client.getSigningKey(kid);
    const signingKey = key.getPublicKey();

    const verified = jwt.verify(token, signingKey, { algorithms: ["RS256"] });
    return verified as { sub: string; email?: string };
  } catch (error) {
    console.error("Token verification failed:", error);
    throw new Error("Unauthorized");
  }
}
